package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.example.data.AppDatabase
import com.example.data.BookRepository
import com.example.ui.BookNotificationHelper
import com.example.ui.BookTrackerScreen
import com.example.ui.BookViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    // Initialize Notification channel
    BookNotificationHelper.createNotificationChannel(applicationContext)

    // Setup Room Db and repo pattern
    val database = AppDatabase.getDatabase(this)
    val repository = BookRepository(database.bookDao())

    // ViewModel injection factory
    val viewModel: BookViewModel by viewModels {
      BookViewModel.Factory(repository)
    }

    setContent {
      MyApplicationTheme {
        BookTrackerScreen(
          viewModel = viewModel,
          modifier = Modifier.fillMaxSize()
        )
      }
    }
  }
}

