package com.example.ui

import android.content.Context
import android.content.Intent
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

data class ReadingSession(
    val id: String = UUID.randomUUID().toString(),
    val bookTitle: String,
    val durationSeconds: Long,
    val timestamp: Long = System.currentTimeMillis()
)

data class DiscoveryBook(
    val title: String,
    val author: String,
    val genre: String,
    val totalPages: Int,
    val description: String = "",
    val readingVibe: String = ""
)

class BookViewModel(private val repository: BookRepository) : ViewModel() {

    // Reactive flow of books
    val books: StateFlow<List<Book>> = repository.allBooks
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Reactive flow of schedules
    val schedules: StateFlow<List<ReadingSchedule>> = repository.allSchedules
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Reactive flow of reading progress logs
    val readingLogs: StateFlow<List<ReadingLog>> = repository.allReadingLogs
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Reactive flow of weekly goals
    val weeklyGoal: StateFlow<WeeklyGoal> = repository.weeklyGoal
        .map { it ?: WeeklyGoal() }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = WeeklyGoal()
        )

    // Reactive flow of in-app notifications
    val notifications: StateFlow<List<InAppNotification>> = repository.allNotifications
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val triggeredScheduleIds = mutableSetOf<Int>()

    init {
        viewModelScope.launch {
            repository.allNotifications.firstOrNull()?.forEach { notif ->
                if (notif.scheduleId != 0) {
                    triggeredScheduleIds.add(notif.scheduleId)
                }
            }
        }
    }

    // Email notifications preferences state
    private val _preferredEmail = MutableStateFlow("anuragphale2@gmail.com")
    val preferredEmail: StateFlow<String> = _preferredEmail.asStateFlow()

    private val _enableAutoEmail = MutableStateFlow(true)
    val enableAutoEmail: StateFlow<Boolean> = _enableAutoEmail.asStateFlow()

    fun loadPreferredEmail(context: Context) {
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        _preferredEmail.value = prefs.getString("preferred_email", "anuragphale2@gmail.com") ?: "anuragphale2@gmail.com"
        _enableAutoEmail.value = prefs.getBoolean("enable_auto_email", true)
    }

    fun savePreferredEmail(context: Context, email: String) {
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("preferred_email", email.trim()).apply()
        _preferredEmail.value = email.trim()
    }

    fun saveEnableAutoEmail(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("enable_auto_email", enabled).apply()
        _enableAutoEmail.value = enabled
    }

    // Reactive flow of reading timer sessions
    private val _timerSessions = MutableStateFlow<List<ReadingSession>>(emptyList())
    val timerSessions: StateFlow<List<ReadingSession>> = _timerSessions.asStateFlow()

    fun loadTimerSessions(context: Context) {
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        val raw = prefs.getString("reading_timer_sessions", "") ?: ""
        if (raw.isEmpty()) {
            _timerSessions.value = emptyList()
            return
        }
        val loaded = raw.split(";;").mapNotNull { line ->
            val parts = line.split("|")
            if (parts.size >= 4) {
                ReadingSession(
                    id = parts[0],
                    bookTitle = parts[1].replace("%7C", "|").replace("%3B", ";"),
                    durationSeconds = parts[2].toLongOrNull() ?: 0L,
                    timestamp = parts[3].toLongOrNull() ?: 0L
                )
            } else null
        }
        _timerSessions.value = loaded.sortedByDescending { it.timestamp }
    }

    fun addTimerSession(context: Context, bookTitle: String, durationSeconds: Long) {
        val newSession = ReadingSession(bookTitle = bookTitle, durationSeconds = durationSeconds)
        val updatedList = _timerSessions.value.toMutableList().apply {
            add(0, newSession)
        }
        _timerSessions.value = updatedList
        
        // Save to SharedPreferences
        val raw = updatedList.joinToString(";;") { session ->
            val safeTitle = session.bookTitle.replace("|", "%7C").replace(";", "%3B")
            "${session.id}|$safeTitle|${session.durationSeconds}|${session.timestamp}"
        }
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("reading_timer_sessions", raw).apply()
    }

    fun clearTimerSessions(context: Context) {
        _timerSessions.value = emptyList()
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove("reading_timer_sessions").apply()
    }

    // Reactive flow of customized Cosmic Discovery Library books
    private val _discoveryLibrary = MutableStateFlow<List<DiscoveryBook>>(emptyList())
    val discoveryLibrary: StateFlow<List<DiscoveryBook>> = _discoveryLibrary.asStateFlow()

    fun loadDiscoveryLibrary(context: Context) {
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        val raw = prefs.getString("custom_discovery_library", "") ?: ""
        if (raw.isEmpty()) {
            _discoveryLibrary.value = emptyList() // Start empty ("clear the cosmic library")
            return
        }
        val loaded = raw.split(";;").mapNotNull { line ->
            val parts = line.split("|")
            if (parts.size >= 4) {
                DiscoveryBook(
                    title = parts[0].replace("%7C", "|").replace("%3B", ";"),
                    author = parts[1].replace("%7C", "|").replace("%3B", ";"),
                    genre = parts[2].replace("%7C", "|").replace("%3B", ";"),
                    totalPages = parts[3].toIntOrNull() ?: 100,
                    description = if (parts.size > 4) parts[4].replace("%7C", "|").replace("%3B", ";") else "",
                    readingVibe = if (parts.size > 5) parts[5].replace("%7C", "|").replace("%3B", ";") else ""
                )
            } else null
        }
        _discoveryLibrary.value = loaded
    }

    fun addDiscoveryBook(context: Context, title: String, author: String, genre: String, totalPages: Int, description: String = "", readingVibe: String = "") {
        if (title.trim().isEmpty() || totalPages <= 0) return
        val newBook = DiscoveryBook(
            title = title.trim(),
            author = author.trim().ifEmpty { "Unknown Author" },
            genre = genre.trim().ifEmpty { "General" },
            totalPages = totalPages,
            description = description.trim().ifEmpty { "A wonderful customized literary piece." },
            readingVibe = readingVibe.trim().ifEmpty { "Personal Choice" }
        )
        val updatedList = _discoveryLibrary.value.toMutableList().apply {
            add(newBook)
        }
        _discoveryLibrary.value = updatedList
        
        // Save to SharedPreferences
        val raw = updatedList.joinToString(";;") { book ->
            val safeTitle = book.title.replace("|", "%7C").replace(";", "%3B")
            val safeAuthor = book.author.replace("|", "%7C").replace(";", "%3B")
            val safeGenre = book.genre.replace("|", "%7C").replace(";", "%3B")
            val safeDesc = book.description.replace("|", "%7C").replace(";", "%3B")
            val safeVibe = book.readingVibe.replace("|", "%7C").replace(";", "%3B")
            "$safeTitle|$safeAuthor|$safeGenre|${book.totalPages}|$safeDesc|$safeVibe"
        }
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().putString("custom_discovery_library", raw).apply()
    }

    fun clearDiscoveryLibrary(context: Context) {
        _discoveryLibrary.value = emptyList()
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        prefs.edit().remove("custom_discovery_library").apply()
    }

    // Active Dashboard Timer State
    private val _isTimerRunning = MutableStateFlow(false)
    val isTimerRunning: StateFlow<Boolean> = _isTimerRunning.asStateFlow()

    private val _timerSecondsElapsed = MutableStateFlow(0L)
    val timerSecondsElapsed: StateFlow<Long> = _timerSecondsElapsed.asStateFlow()

    private val _timerSelectedBookTitle = MutableStateFlow("General Reading Session")
    val timerSelectedBookTitle: StateFlow<String> = _timerSelectedBookTitle.asStateFlow()

    private var timerJob: kotlinx.coroutines.Job? = null

    fun startTimer() {
        if (_isTimerRunning.value) return
        _isTimerRunning.value = true
        timerJob = viewModelScope.launch {
            while (true) {
                kotlinx.coroutines.delay(1000)
                _timerSecondsElapsed.value++
            }
        }
    }

    fun pauseTimer() {
        _isTimerRunning.value = false
        timerJob?.cancel()
        timerJob = null
    }

    fun resetTimer() {
        _isTimerRunning.value = false
        timerJob?.cancel()
        timerJob = null
        _timerSecondsElapsed.value = 0L
    }

    fun setTimerSelectedBookTitle(title: String) {
        _timerSelectedBookTitle.value = title
    }

    // Business functions
    fun checkAndTriggerSchedules(context: Context) {
        val now = System.currentTimeMillis()
        val prefs = context.getSharedPreferences("book_tracker_prefs", Context.MODE_PRIVATE)
        val targetEmail = prefs.getString("preferred_email", "anuragphale2@gmail.com") ?: "anuragphale2@gmail.com"
        val enableAutoEmail = prefs.getBoolean("enable_auto_email", true)

        schedules.value.forEach { schedule ->
            if (!schedule.completed && schedule.dateTimeMillis <= now) {
                if (!triggeredScheduleIds.contains(schedule.id)) {
                    triggeredScheduleIds.add(schedule.id)
                    viewModelScope.launch {
                        val title = "Time to Read: ${schedule.bookTitle}"
                        val message = "It is time to read your target of ${schedule.targetPages} pages!"
                        repository.insertNotification(
                            InAppNotification(
                                title = title,
                                message = message,
                                bookTitle = schedule.bookTitle,
                                scheduleId = schedule.id
                            )
                        )
                    }
                    // Trigger native system notification alarm
                    BookNotificationHelper.showReadingReminder(
                        context = context,
                        bookTitle = schedule.bookTitle,
                        pagesTarget = schedule.targetPages
                    )

                    // Automatically trigger prefill email intent!
                    if (enableAutoEmail) {
                        try {
                            sendScheduleEmail(context, schedule, targetEmail)
                        } catch (e: Exception) {
                            // Suppress background UI launch edge cases
                        }
                    }
                }
            }
        }
    }

    fun triggerInAppNotificationMessage(title: String, message: String, bookTitle: String, scheduleId: Int = 0) {
        viewModelScope.launch {
            repository.insertNotification(
                InAppNotification(
                    title = title,
                    message = message,
                    bookTitle = bookTitle,
                    scheduleId = scheduleId
                )
            )
        }
    }

    fun markNotificationAsRead(id: Int, isRead: Boolean = true) {
        viewModelScope.launch {
            repository.updateNotificationReadStatus(id, isRead)
        }
    }

    fun deleteNotification(id: Int) {
        viewModelScope.launch {
            repository.deleteNotificationById(id)
        }
    }

    fun clearAllNotifications() {
        viewModelScope.launch {
            repository.clearAllNotifications()
        }
    }

    fun addBook(name: String, author: String, genre: String, totalPages: Int, currentPage: Int, uploadedText: String? = null) {
        if (name.trim().isEmpty() || totalPages <= 0) return
        val currentSafe = currentPage.coerceIn(0, totalPages)
        viewModelScope.launch {
            val book = Book(
                title = name.trim(),
                author = author.trim().ifEmpty { "Unknown Author" },
                genre = genre.trim().ifEmpty { "General" },
                totalPages = totalPages,
                currentPage = currentSafe,
                uploadedText = uploadedText
            )
            val newId = repository.insertBook(book)
            if (currentSafe > 0) {
                // Log the initial pages as read today
                repository.insertReadingLog(
                    ReadingLog(
                        bookId = newId.toInt(),
                        bookTitle = book.title,
                        pagesRead = currentSafe
                    )
                )
            }
        }
    }

    fun updateBookProgress(book: Book, newPage: Int) {
        val verifiedPage = newPage.coerceIn(0, book.totalPages)
        val delta = verifiedPage - book.currentPage
        if (delta == 0) return

        viewModelScope.launch {
            val updatedBook = book.copy(currentPage = verifiedPage)
            repository.updateBook(updatedBook)

            if (delta > 0) {
                repository.insertReadingLog(
                    ReadingLog(
                        bookId = book.id,
                        bookTitle = book.title,
                        pagesRead = delta
                    )
                )
            }
        }
    }

    fun deleteBook(book: Book) {
        viewModelScope.launch {
            repository.deleteBook(book)
        }
    }

    fun addSchedule(book: Book, dateTimeMillis: Long, targetPages: Int, notes: String) {
        viewModelScope.launch {
            val schedule = ReadingSchedule(
                bookId = book.id,
                bookTitle = book.title,
                dateTimeMillis = dateTimeMillis,
                targetPages = targetPages,
                notes = notes,
                completed = false
            )
            repository.insertSchedule(schedule)
        }
    }

    fun addCustomSchedule(bookTitle: String, dateTimeMillis: Long, targetPages: Int, notes: String) {
        viewModelScope.launch {
            val schedule = ReadingSchedule(
                bookId = -1,
                bookTitle = bookTitle.trim().ifEmpty { "General Reading" },
                dateTimeMillis = dateTimeMillis,
                targetPages = targetPages,
                notes = notes,
                completed = false
            )
            repository.insertSchedule(schedule)
        }
    }

    fun toggleScheduleCompleted(schedule: ReadingSchedule) {
        viewModelScope.launch {
            repository.updateScheduleCompleted(schedule.id, !schedule.completed)
        }
    }

    fun deleteSchedule(id: Int) {
        viewModelScope.launch {
            repository.deleteScheduleById(id)
        }
    }

    fun updateWeeklyGoal(pagesTarget: Int, booksTarget: Int) {
        viewModelScope.launch {
            repository.insertWeeklyGoal(WeeklyGoal(pagesTarget = pagesTarget, booksTarget = booksTarget))
        }
    }

    // Email client trigger with destination targetEmail address pre-configuration
    fun sendScheduleEmail(context: Context, schedule: ReadingSchedule, targetEmail: String = "anuragphale2@gmail.com") {
        val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy 'at' HH:mm", Locale.getDefault())
        val dateString = dateFormat.format(Date(schedule.dateTimeMillis))
        val bodyText = """
            Hello Book Lover!
            
            This is a prompt to notify you of your upcoming scheduled reading session:
            
            📖 Book Assignment: ${schedule.bookTitle}
            ⏰ Scheduled Time: $dateString
            🎯 Target Milestones: Read ${schedule.targetPages} pages
            
            Memo/Notes:
            ${schedule.notes.ifEmpty { "Prepare your minds, open the pages, and start the journey." }}
            
            Let's maintain your daily reading momentum!
            
            Sent comfortably via Book Tracker App.
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = android.net.Uri.parse("mailto:") // Only email apps should handle this
            putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
            putExtra(Intent.EXTRA_SUBJECT, "📖 Scheduled Read Reminder: ${schedule.bookTitle}")
            putExtra(Intent.EXTRA_TEXT, bodyText)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            val chooser = Intent.createChooser(intent, "Send schedules email to $targetEmail via...")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            try {
                intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(targetEmail))
                context.startActivity(intent)
            } catch (ex: Exception) {
                // Cannot open email applet - let UI display toast
            }
        }
    }

    class Factory(private val repository: BookRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(BookViewModel::class.java)) {
                return BookViewModel(repository) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
