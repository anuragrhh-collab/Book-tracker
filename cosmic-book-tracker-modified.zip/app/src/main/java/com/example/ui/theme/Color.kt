package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CosmicBackground = Color(0xFFF2F6FA) // High-end soft bright ice-blue background (derived from #b3cde0 and light sky)
val CosmicSurface = Color(0xFFFFFFFF)    // Clean white surface for app cards and modules
val CosmicSurfaceVariant = Color(0xFFD3E4F0) // Soft sky-blue layout border container / divider (using #b3cde0)
val CosmicPrimary = Color(0xFF005B96)    // Rich ocean blue for primary action buttons, metrics, and labels
val CosmicSecondary = Color(0xFF6497B1)  // Soft steel blue for progress bars, secondary controls, and helper icons
val CosmicTertiary = Color(0xFFBF9B30)   // Warm antique gold for achievement badges, completed milestones, and stars

val CosmicOnBackground = Color(0xFF011F4B) // Deepest royal navy for headers, bold text (very high hierarchy, high readability)
val CosmicOnSurface = Color(0xFF03396C)    // Dark blue-grey for main body copy and card descriptions
val CosmicOnSurfaceMuted = Color(0xFF6497B1) // Soft steel blue for secondary subtext and units (e.g., "pgs")

// Priority levels
val PriorityHigh = Color(0xFFD94D6C)     // Soft coral red/pink
val PriorityMedium = Color(0xFFFFAE19)   // Warm glow amber-orange (derived from #ffbf00)
val PriorityLow = Color(0xFF5CB85C)      // Gentle emerald success green

