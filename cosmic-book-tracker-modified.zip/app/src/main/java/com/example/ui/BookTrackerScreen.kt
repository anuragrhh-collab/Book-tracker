package com.example.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Book
import com.example.data.ReadingLog
import com.example.data.ReadingSchedule
import com.example.data.WeeklyGoal
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun BookTrackerScreen(
    viewModel: BookViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current

    // Observe flows from ViewModel
    val books by viewModel.books.collectAsStateWithLifecycle()
    val schedules by viewModel.schedules.collectAsStateWithLifecycle()
    val readingLogs by viewModel.readingLogs.collectAsStateWithLifecycle()
    val goal by viewModel.weeklyGoal.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()
    val preferredEmail by viewModel.preferredEmail.collectAsStateWithLifecycle()
    val enableAutoEmail by viewModel.enableAutoEmail.collectAsStateWithLifecycle()
    val timerSessions by viewModel.timerSessions.collectAsStateWithLifecycle()
    val isTimerRunning by viewModel.isTimerRunning.collectAsStateWithLifecycle()
    val timerSecondsElapsed by viewModel.timerSecondsElapsed.collectAsStateWithLifecycle()
    val timerSelectedBookTitle by viewModel.timerSelectedBookTitle.collectAsStateWithLifecycle()
    val discoveryLibrary by viewModel.discoveryLibrary.collectAsStateWithLifecycle()

    val unreadCount = remember(notifications) { notifications.count { !it.isRead } }

    // Screen tab local state: "Dashboard", "Goals", "Calendar & Schedule"
    var currentTab by remember { mutableStateOf("Dashboard") }

    // Forms local states
    var showAddBookForm by remember { mutableStateOf(false) }
    var bookTitleInput by remember { mutableStateOf("") }
    var bookAuthorInput by remember { mutableStateOf("") }
    var bookGenreInput by remember { mutableStateOf("Fiction") }
    var bookTotalPagesInput by remember { mutableStateOf("") }
    var bookCurPagesInput by remember { mutableStateOf("") }
    var bookUploadedText by remember { mutableStateOf<String?>(null) }
    var activeReaderBook by remember { mutableStateOf<Book?>(null) }

    // Schedules adding dialog / local pickers
    var scheduleBookSelected by remember { mutableStateOf<Book?>(null) }
    var scheduleDateMills by remember { mutableStateOf(0L) }
    var schedulePagesToReadInput by remember { mutableStateOf("15") }
    var scheduleNotesInput by remember { mutableStateOf("") }
    var showAddScheduleForm by remember { mutableStateOf(false) }

    // Double check goal editor
    var showGoalEditor by remember { mutableStateOf(false) }
    var goalPagesInput by remember { mutableStateOf(goal.pagesTarget.toString()) }
    var goalBooksInput by remember { mutableStateOf(goal.booksTarget.toString()) }

    // Sync goal state edit input helper
    LaunchedEffect(goal) {
        goalPagesInput = goal.pagesTarget.toString()
        goalBooksInput = goal.booksTarget.toString()
    }

    // Dynamic clock
    var currentTimeString by remember { mutableStateOf("00:00") }
    var currentDateString by remember { mutableStateOf("") }
    var greetingText by remember { mutableStateOf("Welcome, Reader") }

    LaunchedEffect(Unit) {
        viewModel.loadPreferredEmail(context)
        viewModel.loadTimerSessions(context)
        viewModel.loadDiscoveryLibrary(context)
        while (true) {
            val now = Calendar.getInstance()
            val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
            val dateFormat = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
            currentTimeString = timeFormat.format(now.time)
            currentDateString = dateFormat.format(now.time)

            val hour = now.get(Calendar.HOUR_OF_DAY)
            greetingText = when (hour) {
                in 5..11 -> "Welcome back, morning star reader"
                in 12..17 -> "Good afternoon, cozy reading seeker"
                in 18..22 -> "Good evening, bedtime chapter reader"
                else -> "Quiet night. Peaceful pages await"
            }
            viewModel.checkAndTriggerSchedules(context)
            delay(1000)
        }
    }

    // Math statistics
    val totalActiveBooksCount = books.count { !it.isCompleted }
    val completedBooksCount = books.count { it.isCompleted }
    val totalRemainingPages = books.filter { !it.isCompleted }.sumOf { it.remainingPages }

    // Calculate pages read this week
    val startOfWeekMillis = remember(readingLogs) {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.clear(Calendar.MINUTE)
        cal.clear(Calendar.SECOND)
        cal.clear(Calendar.MILLISECOND)
        cal.set(Calendar.DAY_OF_WEEK, cal.firstDayOfWeek)
        cal.timeInMillis
    }
    val pagesReadThisWeek = remember(readingLogs, startOfWeekMillis) {
        readingLogs.filter { it.dateEpochMillis >= startOfWeekMillis }.sumOf { it.pagesRead }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .safeDrawingPadding(),
        containerColor = CosmicBackground,
        bottomBar = {
            // High fidelity modern navbar
            NavigationBar(
                containerColor = CosmicSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = currentTab == "Goals",
                    onClick = { currentTab = "Goals" },
                    icon = { Icon(Icons.Default.Leaderboard, contentDescription = "Weekly Goals status") },
                    label = { Text("Goals") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicPrimary,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicOnSurfaceMuted,
                        unselectedTextColor = CosmicOnSurfaceMuted,
                        indicatorColor = CosmicSurfaceVariant
                    )
                )

                NavigationBarItem(
                    selected = currentTab == "Dashboard",
                    onClick = { currentTab = "Dashboard" },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text("Dashboard") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicPrimary,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicOnSurfaceMuted,
                        unselectedTextColor = CosmicOnSurfaceMuted,
                        indicatorColor = CosmicSurfaceVariant
                    )
                )

                NavigationBarItem(
                    selected = currentTab == "Schedule",
                    onClick = { currentTab = "Schedule" },
                    icon = { Icon(Icons.Default.DateRange, contentDescription = "Schedule readings") },
                    label = { Text("Schedule") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicPrimary,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicOnSurfaceMuted,
                        unselectedTextColor = CosmicOnSurfaceMuted,
                        indicatorColor = CosmicSurfaceVariant
                    )
                )

                NavigationBarItem(
                    selected = currentTab == "Alerts",
                    onClick = { currentTab = "Alerts" },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (unreadCount > 0) {
                                    Badge(
                                        containerColor = PriorityHigh,
                                        contentColor = CosmicBackground
                                    ) {
                                        Text("$unreadCount", fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = if (unreadCount > 0) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                contentDescription = "Active Alerts"
                            )
                        }
                    },
                    label = { Text("Alerts") },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = CosmicPrimary,
                        selectedTextColor = CosmicPrimary,
                        unselectedIconColor = CosmicOnSurfaceMuted,
                        unselectedTextColor = CosmicOnSurfaceMuted,
                        indicatorColor = CosmicSurfaceVariant
                    )
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // HEADER SECTION
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = greetingText.uppercase(Locale.getDefault()),
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.2.sp,
                            color = CosmicSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Cosmic Reading Oasis",
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = CosmicOnBackground,
                            fontWeight = FontWeight.Black
                        )
                    )
                }
                Row {
                    OutlinedButton(onClick = { Toast.makeText(context,"Google Sign-In placeholder",Toast.LENGTH_SHORT).show() }) {
                        Text("Sign In")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(onClick = { Toast.makeText(context,"Google Drive Link placeholder",Toast.LENGTH_SHORT).show() }) {
                        Text("Drive")
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // TAB MULTIPLEXERS
            when (currentTab) {
                "Dashboard" -> {
                    DashboardTab(
                        books = books,
                        readingLogs = readingLogs,
                        totalActiveBooksCount = totalActiveBooksCount,
                        completedBooksCount = completedBooksCount,
                        totalRemainingPages = totalRemainingPages,
                        showAddBookForm = showAddBookForm,
                        onToggleAddBook = { showAddBookForm = !showAddBookForm },
                        bookTitleInput = bookTitleInput,
                        onTitleChange = { bookTitleInput = it },
                        bookAuthorInput = bookAuthorInput,
                        onAuthorChange = { bookAuthorInput = it },
                        bookGenreInput = bookGenreInput,
                        onGenreChange = { bookGenreInput = it },
                        bookTotalPagesInput = bookTotalPagesInput,
                        onTotalPagesChange = { bookTotalPagesInput = it },
                        bookCurPagesInput = bookCurPagesInput,
                        onCurPagesChange = { bookCurPagesInput = it },
                        uploadedText = bookUploadedText,
                        onUploadedTextChange = { bookUploadedText = it },
                        onAddBookSubmit = {
                            val total = bookTotalPagesInput.toIntOrNull() ?: 0
                            val cur = bookCurPagesInput.toIntOrNull() ?: 0
                            if (bookTitleInput.trim().isEmpty()) {
                                Toast.makeText(context, "Please enter a Book Name", Toast.LENGTH_SHORT).show()
                            } else if (total <= 0) {
                                Toast.makeText(context, "Total pages must be a positive integer", Toast.LENGTH_SHORT).show()
                            } else {
                                viewModel.addBook(
                                    name = bookTitleInput,
                                    author = bookAuthorInput,
                                    genre = bookGenreInput,
                                    totalPages = total,
                                    currentPage = cur,
                                    uploadedText = bookUploadedText
                                )
                                // Clear inputs
                                bookTitleInput = ""
                                bookAuthorInput = ""
                                bookGenreInput = "Fiction"
                                bookTotalPagesInput = ""
                                bookCurPagesInput = ""
                                bookUploadedText = null
                                showAddBookForm = false
                                keyboardController?.hide()
                                Toast.makeText(context, "Book registered to orbital shelf!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onUpdatePages = { book, newPages ->
                            viewModel.updateBookProgress(book, newPages)
                        },
                        onDeleteBook = { book ->
                            viewModel.deleteBook(book)
                            Toast.makeText(context, "Book removed from shelf", Toast.LENGTH_SHORT).show()
                        },
                        onAddBookFromLibrary = { title, author, genre, totalPages ->
                            viewModel.addBook(
                                name = title,
                                author = author,
                                genre = genre,
                                totalPages = totalPages,
                                currentPage = 0
                            )
                        },
                        onOpenReader = { activeReaderBook = it },
                        timerSessions = timerSessions,
                        onAddTimerSession = { bookTitle, seconds -> viewModel.addTimerSession(context, bookTitle, seconds) },
                        onClearTimerSessions = { viewModel.clearTimerSessions(context) },
                        timerSecondsElapsed = timerSecondsElapsed,
                        isTimerRunning = isTimerRunning,
                        timerSelectedBookTitle = timerSelectedBookTitle,
                        onStartTimer = { viewModel.startTimer() },
                        onPauseTimer = { viewModel.pauseTimer() },
                        onResetTimer = { viewModel.resetTimer() },
                        onSetTimerSelectedBookTitle = { viewModel.setTimerSelectedBookTitle(it) },
                        discoveryLibrary = discoveryLibrary,
                        onAddDiscoveryBook = { title, auth, gen, pgs, desc, vibe -> viewModel.addDiscoveryBook(context, title, auth, gen, pgs, desc, vibe) },
                        onClearDiscoveryLibrary = { viewModel.clearDiscoveryLibrary(context) }
                    )
                }

                "Schedule" -> {
                    ScheduleTab(
                        books = books,
                        schedules = schedules,
                        showAddScheduleForm = showAddScheduleForm,
                        onToggleAddSchedule = { showAddScheduleForm = !showAddScheduleForm },
                        scheduleBookSelected = scheduleBookSelected,
                        onBookSelect = { scheduleBookSelected = it },
                        scheduleDateMills = scheduleDateMills,
                        onDateSelect = { scheduleDateMills = it },
                        schedulePagesToReadInput = schedulePagesToReadInput,
                        onPagesChange = { schedulePagesToReadInput = it },
                        scheduleNotesInput = scheduleNotesInput,
                        onNotesChange = { scheduleNotesInput = it },
                        onAddScheduleSubmit = { useManual, customTitle ->
                            val target = schedulePagesToReadInput.toIntOrNull() ?: 15
                            if (scheduleDateMills == 0L) {
                                Toast.makeText(context, "Please select Date & Time", Toast.LENGTH_SHORT).show()
                            } else if (useManual) {
                                if (customTitle.trim().isEmpty()) {
                                    Toast.makeText(context, "Please enter a Book Name", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.addCustomSchedule(
                                        bookTitle = customTitle.trim(),
                                        dateTimeMillis = scheduleDateMills,
                                        targetPages = target,
                                        notes = scheduleNotesInput
                                    )
                                    showAddScheduleForm = false
                                    scheduleBookSelected = null
                                    scheduleDateMills = 0L
                                    scheduleNotesInput = ""
                                    Toast.makeText(context, "Reading event scheduled successfully!", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                val book = scheduleBookSelected
                                if (book == null) {
                                    Toast.makeText(context, "Select a book to schedule", Toast.LENGTH_SHORT).show()
                                } else {
                                    viewModel.addSchedule(
                                        book = book,
                                        dateTimeMillis = scheduleDateMills,
                                        targetPages = target,
                                        notes = scheduleNotesInput
                                    )
                                    showAddScheduleForm = false
                                    scheduleBookSelected = null
                                    scheduleDateMills = 0L
                                    scheduleNotesInput = ""
                                    Toast.makeText(context, "Reading event scheduled successfully!", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        onDeleteSchedule = { scheduleId ->
                            viewModel.deleteSchedule(scheduleId)
                        },
                        onToggleSchedule = { schedule ->
                            viewModel.toggleScheduleCompleted(schedule)
                        },
                        onTriggerEmail = { schedule ->
                            viewModel.sendScheduleEmail(context, schedule, preferredEmail)
                        },
                        onTriggerNotification = { schedule ->
                            BookNotificationHelper.showReadingReminder(
                                context = context,
                                bookTitle = schedule.bookTitle,
                                pagesTarget = schedule.targetPages
                            )
                            Toast.makeText(context, "Native system reminder notification simulated!", Toast.LENGTH_LONG).show()
                        },
                        preferredEmail = preferredEmail,
                        onSaveEmail = { viewModel.savePreferredEmail(context, it) },
                        enableAutoEmail = enableAutoEmail,
                        onToggleAutoEmail = { viewModel.saveEnableAutoEmail(context, it) }
                    )
                }

                "Goals" -> {
                    GoalsTab(
                        goal = goal,
                        pagesReadThisWeek = pagesReadThisWeek,
                        readingLogs = readingLogs,
                        showGoalEditor = showGoalEditor,
                        onToggleGoalEditor = { showGoalEditor = !showGoalEditor },
                        goalPagesInput = goalPagesInput,
                        onGoalPagesChange = { goalPagesInput = it },
                        goalBooksInput = goalBooksInput,
                        onGoalBooksChange = { goalBooksInput = it },
                        onSaveGoals = {
                            val targetP = goalPagesInput.toIntOrNull() ?: 100
                            val targetB = goalBooksInput.toIntOrNull() ?: 1
                            viewModel.updateWeeklyGoal(targetP, targetB)
                            showGoalEditor = false
                            Toast.makeText(context, "Weekly goals updated!", Toast.LENGTH_SHORT).show()

                            // Simulate sending weekly updates as notification
                            val percentage = if (targetP > 0) (pagesReadThisWeek * 100 / targetP) else 0
                            BookNotificationHelper.showWeeklyGoalNotification(context, percentage)
                        }
                    )
                }

                "Alerts" -> {
                    AlertsTab(
                        notifications = notifications,
                        onMarkAsRead = { notif ->
                            viewModel.markNotificationAsRead(notif.id, true)
                        },
                        onDeleteNotification = { notifId ->
                            viewModel.deleteNotification(notifId)
                        },
                        onClearAll = {
                            viewModel.clearAllNotifications()
                            Toast.makeText(context, "Alert history cleared!", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }

            // In-App E-Reader dialog overlay
            if (activeReaderBook != null) {
                val rBook = activeReaderBook!!
                var currentPageIndex by remember(rBook) { mutableStateOf((rBook.currentPage - 1).coerceIn(0, rBook.totalPages - 1)) }
                val pages = remember(rBook) { getBookPages(rBook) }
                val currentPageText = pages.getOrElse(currentPageIndex) { "End of document reached." }

                Dialog(
                    onDismissRequest = { activeReaderBook = null },
                    properties = DialogProperties(usePlatformDefaultWidth = false)
                ) {
                    Card(
                        shape = RoundedCornerShape(0.dp), // Full screen card
                        colors = CardDefaults.cardColors(containerColor = CosmicBackground),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp)
                        ) {
                            // Header
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = rBook.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = CosmicPrimary,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "by ${rBook.author}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CosmicOnSurfaceMuted
                                    )
                                }

                                IconButton(onClick = { activeReaderBook = null }) {
                                    Icon(Icons.Default.Close, contentDescription = "Close Reader", tint = CosmicOnBackground)
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Reader progression indicator
                            LinearProgressIndicator(
                                progress = { (currentPageIndex + 1).toFloat() / rBook.totalPages.toFloat() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(CircleShape),
                                color = CosmicTertiary,
                                trackColor = CosmicSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            // Content scrollable pane
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(CosmicSurface)
                                    .padding(20.dp)
                            ) {
                                LazyColumn(modifier = Modifier.fillMaxSize()) {
                                    item {
                                        Text(
                                            text = currentPageText,
                                            style = MaterialTheme.typography.bodyLarge.copy(
                                                lineHeight = 24.sp,
                                                fontFamily = FontFamily.Serif
                                            ),
                                            color = CosmicOnBackground
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Action pagination tools
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = {
                                        if (currentPageIndex > 0) {
                                            currentPageIndex--
                                        }
                                    },
                                    enabled = currentPageIndex > 0,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CosmicSurfaceVariant,
                                        contentColor = CosmicOnSurface
                                    )
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Previous Page", modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Prev")
                                }

                                Text(
                                    text = "Page ${currentPageIndex + 1} of ${rBook.totalPages}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = CosmicSecondary
                                )

                                Button(
                                    onClick = {
                                        if (currentPageIndex < rBook.totalPages - 1) {
                                            currentPageIndex++
                                        }
                                    },
                                    enabled = currentPageIndex < rBook.totalPages - 1,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = CosmicSurfaceVariant,
                                        contentColor = CosmicOnSurface
                                    )
                                ) {
                                    Text("Next")
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Next Page", modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Sync log tool
                            Button(
                                onClick = {
                                    val targetP = currentPageIndex + 1
                                    viewModel.updateBookProgress(rBook, targetP)
                                    Toast.makeText(context, "Progress sync'd to cosmic tracker: Page $targetP", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("sync_reader_progress_btn"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CosmicTertiary,
                                    contentColor = CosmicBackground
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(Icons.Default.Sync, contentDescription = "Synchronize progress", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Sync Read Count with Goals Tracker", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

// In-App E-Reader dynamic page-chopping parser tool
fun getBookPages(book: Book): List<String> {
    val text = book.uploadedText
    if (!text.isNullOrEmpty()) {
        val chunked = text.chunked(1500)
        return if (chunked.isNotEmpty()) chunked else listOf("Empty content.")
    }
    
    val classicContent = when (book.title.lowercase()) {
        "cosmos" -> listOf(
            "Chapter 1: The Cosmic Ocean\n\nThe Cosmos is all that is or was or ever will be. Our feeblest contemplations of the Cosmos stir us — there is a tingling in the spine, a catch in the voice, a faint sensation, as if a distant memory, of falling from a height. We know we are approaching the greatest of mysteries.",
            "The size and age of the Cosmos are beyond ordinary human understanding. Lost somewhere between immensity and eternity is our tiny planetary home. In a cosmic perspective, most human concerns seem insignificant, even petty.",
            "Yet our species is young and curious and brave and shows much promise. In the last few millennia we have made the most astonishing and unexpected discoveries about the Cosmos and our place within it, reminders that humans are organic to the universe, space-times that have become conscious."
        )
        "dune" -> listOf(
            "Chapter 1: The Arrakis Prophecy\n\nA beginning is the time for taking the most delicate care that the balances are correct. This every sister of the Bene Gesserit knows. To begin your study of the life of Muad'Dib, then, take care that you first place him in his time: born in the 57th year of the Padishah Emperor Shaddam IV.",
            "Arrakis, the desert planet, is a place of endless spice and silent death. The sand crawls with behemoth worms, yet within its parched lands lies the source of supreme prescience.",
            "Fear is the mind-killer. Fear is the little-death that brings total obliteration. I will face my fear. I will permit it to pass over me and through me. And when it has gone past I will turn the inner eye to see its path."
        )
        "the hobbit" -> listOf(
            "Chapter 1: An Unexpected Party\n\nIn a hole in the ground there lived a hobbit. Not a nasty, dirty, wet hole, filled with the ends of worms and an oozy smell, nor yet a dry, bare, sandy hole with nothing in it to sit down on or to eat: it was a hobbit-hole, and that means comfort.",
            "It had a perfectly round door like a porthole, painted green, with a shiny yellow brass knob in the exact middle. The door opened on to a tube-shaped hall like a tunnel: a very comfortable tunnel without smoke, with panelled walls, and floors tiled and carpeted.",
            "The Bagginses had lived in the neighborhood of The Hill for time out of mind, and people considered them very respectable, not only because most of them were rich, but also because they never had any adventures or did anything unexpected."
        )
        else -> listOf(
            "Chapter 1: Celestial Expansion\n\nWelcome to your customized reader portal, navigating through the starry dimensions of '${book.title}'. Under this beautiful slate theme, every word counts as a healthy habit, aligning your attention like a cosmic needle.",
            "As you flip through these pages, remember that compound success builds precisely like gravity: 1% betterment daily accelerates your momentum exponentially. Keep reading, keep logging, and keep reaching your targets!",
            "Thank you for logging your journey. This document is fully simulated and waiting for you to expand your celestial horizons."
        )
    }
    
    val resultPages = mutableListOf<String>()
    val numPages = book.totalPages.coerceAtLeast(1)
    for (i in 0 until numPages) {
        val baseIndex = i % classicContent.size
        val pageText = classicContent[baseIndex]
        resultPages.add("Page ${i + 1}\n\n$pageText")
    }
    return resultPages
}

// ==================== DISCOVERY LIBRARY HELPER ====================
// DiscoveryBook is defined dynamically in BookViewModel.kt.


// ==================== DASHBOARD TAB ====================
@Composable
fun DashboardTab(
    books: List<Book>,
    readingLogs: List<ReadingLog>,
    totalActiveBooksCount: Int,
    completedBooksCount: Int,
    totalRemainingPages: Int,
    showAddBookForm: Boolean,
    onToggleAddBook: () -> Unit,
    bookTitleInput: String,
    onTitleChange: (String) -> Unit,
    bookAuthorInput: String,
    onAuthorChange: (String) -> Unit,
    bookGenreInput: String,
    onGenreChange: (String) -> Unit,
    bookTotalPagesInput: String,
    onTotalPagesChange: (String) -> Unit,
    bookCurPagesInput: String,
    onCurPagesChange: (String) -> Unit,
    uploadedText: String?,
    onUploadedTextChange: (String?) -> Unit,
    onAddBookSubmit: () -> Unit,
    onUpdatePages: (Book, Int) -> Unit,
    onDeleteBook: (Book) -> Unit,
    onAddBookFromLibrary: (String, String, String, Int) -> Unit,
    onOpenReader: (Book) -> Unit,
    timerSessions: List<ReadingSession>,
    onAddTimerSession: (String, Long) -> Unit,
    onClearTimerSessions: () -> Unit,
    timerSecondsElapsed: Long,
    isTimerRunning: Boolean,
    timerSelectedBookTitle: String,
    onStartTimer: () -> Unit,
    onPauseTimer: () -> Unit,
    onResetTimer: () -> Unit,
    onSetTimerSelectedBookTitle: (String) -> Unit,
    discoveryLibrary: List<com.example.ui.DiscoveryBook>,
    onAddDiscoveryBook: (String, String, String, Int, String, String) -> Unit,
    onClearDiscoveryLibrary: () -> Unit
) {
    val context = LocalContext.current
    
    var showAddToLibraryForm by remember { mutableStateOf(false) }
    var libBookTitle by remember { mutableStateOf("") }
    var libBookAuthor by remember { mutableStateOf("") }
    var libBookGenre by remember { mutableStateOf("Fiction") }
    var libBookPages by remember { mutableStateOf("") }
    var libBookVibe by remember { mutableStateOf("") }
    var libBookDesc by remember { mutableStateOf("") }

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            try {
                val contentResolver = context.contentResolver
                var fileName = "Uploaded Book"
                contentResolver.query(it, null, null, null, null)?.use { cursor ->
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1 && cursor.moveToFirst()) {
                        fileName = cursor.getString(nameIndex)
                    }
                }
                
                val inputStream = contentResolver.openInputStream(it)
                val bytes = inputStream?.readBytes()
                val textContent = bytes?.toString(Charsets.UTF_8) ?: ""
                
                val charCount = textContent.length
                val calculatedPages = (charCount / 1500).coerceAtLeast(1)
                
                val cleanTitle = if (fileName.contains(".")) {
                    fileName.substringBeforeLast(".")
                } else {
                    fileName
                }
                
                onTitleChange(cleanTitle)
                onAuthorChange("Uploaded Link")
                onTotalPagesChange(calculatedPages.toString())
                onCurPagesChange("0")
                onGenreChange("Science")
                onUploadedTextChange(textContent)
                
                if (!showAddBookForm) {
                    onToggleAddBook()
                }
                
                Toast.makeText(context, "Loaded '$cleanTitle' (~$calculatedPages pages)", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Failed to load document: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Stats widgets
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Widget 1: Remaining books
                Card(
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Active Books", style = MaterialTheme.typography.labelMedium, color = CosmicOnSurfaceMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$totalActiveBooksCount", style = MaterialTheme.typography.headlineMedium, color = CosmicPrimary, fontWeight = FontWeight.Black)
                        Text("$completedBooksCount completed", style = MaterialTheme.typography.labelSmall, color = CosmicTertiary)
                    }
                }

                // Widget 2: Remaining pages
                Card(
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("Pages Unfinished", style = MaterialTheme.typography.labelMedium, color = CosmicOnSurfaceMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("$totalRemainingPages", style = MaterialTheme.typography.headlineMedium, color = PriorityHigh, fontWeight = FontWeight.Black)
                        val totalOriginal = books.sumOf { it.totalPages }
                        val finished = totalOriginal - totalRemainingPages
                        Text("$finished pages completed", style = MaterialTheme.typography.labelSmall, color = CosmicOnSurfaceMuted)
                    }
                }
            }
        }

        // Expanded Page Log Graph (Past 7 Days History)
        item {
            WeeklyReadingLogGraph(readingLogs = readingLogs)
        }

        // INTEGRATED READING TIMER WIDGET
        item {
            var showBookSelectorDropdown by remember { mutableStateOf(false) }
            val formattedTime = remember(timerSecondsElapsed) {
                val h = timerSecondsElapsed / 3600
                val m = (timerSecondsElapsed % 3600) / 60
                val s = timerSecondsElapsed % 60
                if (h > 0) String.format("%02d:%02d:%02d", h, m, s)
                else String.format("%02d:%02d", m, s)
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CosmicSurfaceVariant),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("reading_timer_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer Icon",
                                tint = CosmicPrimary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Reading Session Timer",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CosmicOnBackground
                            )
                        }
                        
                        if (isTimerRunning) {
                            Surface(
                                shape = CircleShape,
                                color = PriorityLow.copy(alpha = 0.2f),
                                contentColor = PriorityLow,
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .clip(CircleShape)
                                            .background(PriorityLow)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Active Live Session", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Track your focused study hours and build strong reading focus. Select a book from your shelf to log duration directly.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CosmicOnSurfaceMuted,
                        lineHeight = 15.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Selection of target book dropdown
                    Box(modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = { if (!isTimerRunning) showBookSelectorDropdown = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CosmicSurfaceVariant,
                                contentColor = CosmicOnSurface
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !isTimerRunning
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Book, contentDescription = "Book Target", modifier = Modifier.size(16.dp), tint = CosmicPrimary)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = timerSelectedBookTitle,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        overflow = TextOverflow.Ellipsis,
                                        maxLines = 1
                                    )
                                }
                                if (!isTimerRunning) {
                                    Icon(Icons.Default.ArrowDropDown, contentDescription = "Open selections")
                                }
                            }
                        }

                        DropdownMenu(
                            expanded = showBookSelectorDropdown,
                            onDismissRequest = { showBookSelectorDropdown = false },
                            modifier = Modifier.background(CosmicSurface)
                        ) {
                            DropdownMenuItem(
                                text = { Text("General Session (Free Read)", color = CosmicOnBackground) },
                                onClick = {
                                    onSetTimerSelectedBookTitle("General Reading Session")
                                    showBookSelectorDropdown = false
                                }
                            )
                            books.forEach { activeBook ->
                                DropdownMenuItem(
                                    text = { Text(activeBook.title, color = CosmicOnBackground) },
                                    onClick = {
                                        onSetTimerSelectedBookTitle(activeBook.title)
                                        showBookSelectorDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // Timer Counter Clock representation
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = formattedTime,
                            style = MaterialTheme.typography.displayMedium.copy(
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = CosmicPrimary
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    // CONTROL PANEL ACTIONS
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (!isTimerRunning) {
                            Button(
                                onClick = onStartTimer,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CosmicPrimary,
                                    contentColor = CosmicBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("start_timer_button")
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Start Timer")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Start Study", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = onPauseTimer,
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = CosmicTertiary,
                                    contentColor = CosmicBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("pause_timer_button")
                            ) {
                                Icon(Icons.Default.Pause, contentDescription = "Pause Timer")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Pause Timer", fontWeight = FontWeight.Bold)
                            }
                        }

                        if (timerSecondsElapsed > 0) {
                            // Stop & Log session option
                            Button(
                                onClick = {
                                    onPauseTimer()
                                    if (timerSecondsElapsed >= 2) {
                                        onAddTimerSession(timerSelectedBookTitle, timerSecondsElapsed)
                                        Toast.makeText(context, "Session saved: $formattedTime of reading", Toast.LENGTH_LONG).show()
                                    } else {
                                        Toast.makeText(context, "Session too short to save.", Toast.LENGTH_SHORT).show()
                                    }
                                    onResetTimer()
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = PriorityHigh,
                                    contentColor = CosmicBackground
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(44.dp)
                                    .testTag("log_timer_button")
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Log Session")
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Log Session", fontWeight = FontWeight.Bold)
                            }
                            
                            // Cancel/Reset button
                            IconButton(
                                onClick = {
                                    onPauseTimer()
                                    onResetTimer()
                                    Toast.makeText(context, "Session discarded", Toast.LENGTH_SHORT).show()
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(CosmicSurfaceVariant, shape = RoundedCornerShape(12.dp))
                                    .testTag("reset_timer_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Reset Timer", tint = CosmicOnSurface)
                            }
                        }
                    }

                    // Log history of modern timer sessions!
                    if (timerSessions.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(18.dp))
                        HorizontalDivider(color = CosmicSurfaceVariant, thickness = 1.dp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Logged Timer Sessions",
                                style = MaterialTheme.typography.labelLarge,
                                fontWeight = FontWeight.Bold,
                                color = CosmicOnBackground
                            )
                            TextButton(onClick = onClearTimerSessions) {
                                Text("Clear", style = MaterialTheme.typography.labelSmall, color = PriorityHigh, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Column(
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            timerSessions.take(5).forEach { session ->
                                val sessionDurationText = remember(session.durationSeconds) {
                                    val m = session.durationSeconds / 60
                                    val s = session.durationSeconds % 60
                                    if (m > 0) "${m}m ${s}s" else "${s}s"
                                }
                                val dateText = remember(session.timestamp) {
                                    val sdf = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
                                    sdf.format(Date(session.timestamp))
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(CosmicSurfaceVariant.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Default.Timeline,
                                            contentDescription = "Session duration icon",
                                            tint = CosmicSecondary,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Column {
                                            Text(
                                                text = session.bookTitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                fontWeight = FontWeight.Bold,
                                                color = CosmicOnBackground,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = dateText,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CosmicOnSurfaceMuted,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                    
                                    Text(
                                        text = sessionDurationText,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = CosmicSecondary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Add Book Header Form Toggle
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reading Shelf",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = CosmicOnBackground
                    )
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    // Upload button
                    IconButton(
                        onClick = { filePickerLauncher.launch("*/*") },
                        modifier = Modifier
                            .background(CosmicTertiary.copy(alpha = 0.2f), shape = RoundedCornerShape(12.dp))
                            .size(height = 40.dp, width = 44.dp)
                            .testTag("upload_file_header_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.CloudUpload,
                            contentDescription = "Upload Book File",
                            tint = CosmicTertiary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Button(
                        onClick = onToggleAddBook,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (showAddBookForm) PriorityHigh.copy(alpha = 0.2f) else CosmicPrimary,
                            contentColor = if (showAddBookForm) PriorityHigh else CosmicBackground
                        ),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Icon(
                            imageVector = if (showAddBookForm) Icons.Default.Close else Icons.Default.Add,
                            contentDescription = "Addition Form Control",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (showAddBookForm) "Close" else "Record Book", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Inline Expandable Add Book Form
        if (showAddBookForm) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Add New Book", style = MaterialTheme.typography.titleSmall, color = CosmicPrimary, fontWeight = FontWeight.Bold)

                        // Integrated E-Book File attachment banner
                        if (uploadedText == null) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CosmicSurfaceVariant.copy(alpha = 0.5f))
                                    .clickable { filePickerLauncher.launch("*/*") }
                                    .padding(vertical = 12.dp, horizontal = 16.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.CloudUpload,
                                        contentDescription = "Upload icon",
                                        tint = CosmicSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Text(
                                        text = "Import from device (.txt / e-book file)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CosmicSecondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        } else {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(CosmicSecondary.copy(alpha = 0.15f))
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Drafts,
                                        contentDescription = "Document icon",
                                        tint = CosmicTertiary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text(
                                            text = "Document Linked Successfully",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CosmicTertiary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${uploadedText.length} characters loaded in-app reader",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = CosmicOnSurfaceMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                TextButton(
                                    onClick = {
                                        onUploadedTextChange(null)
                                        onTitleChange("")
                                        onAuthorChange("")
                                        onTotalPagesChange("")
                                        onCurPagesChange("")
                                    }
                                ) {
                                    Text("Clear", color = PriorityHigh, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }

                        OutlinedTextField(
                            value = bookTitleInput,
                            onValueChange = onTitleChange,
                            label = { Text("Book Title") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicPrimary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("book_title_field")
                        )

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = bookAuthorInput,
                                onValueChange = onAuthorChange,
                                label = { Text("Author") },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicPrimary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("book_author_field")
                            )

                            // Genre Select
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Genre", style = MaterialTheme.typography.labelSmall, color = CosmicSecondary)
                                var expandedGenre by remember { mutableStateOf(false) }
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 4.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CosmicSurfaceVariant)
                                        .clickable { expandedGenre = true }
                                        .padding(12.dp)
                                ) {
                                    Text(bookGenreInput, color = CosmicOnSurface)
                                    DropdownMenu(
                                        expanded = expandedGenre,
                                        onDismissRequest = { expandedGenre = false }
                                    ) {
                                        listOf("Fiction", "Non-fiction", "History", "Science", "Self-Help", "Fantasy", "Biography").forEach { gen ->
                                            DropdownMenuItem(
                                                text = { Text(gen) },
                                                onClick = {
                                                    onGenreChange(gen)
                                                    expandedGenre = false
                                                }
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = bookTotalPagesInput,
                                onValueChange = onTotalPagesChange,
                                label = { Text("Total Pages") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicPrimary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("book_total_pages_field")
                            )

                            OutlinedTextField(
                                value = bookCurPagesInput,
                                onValueChange = onCurPagesChange,
                                label = { Text("Current Page") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicPrimary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("book_current_page_field")
                            )
                        }

                        Button(
                            onClick = onAddBookSubmit,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicTertiary, contentColor = CosmicBackground),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("book_register_submit")
                        ) {
                            Text("Dock Book to Celestial Shelf", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active bookshelf listing Empty status
        if (books.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp)
                        .testTag("books_empty_state"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Empty Shelf icon",
                            tint = CosmicPrimary.copy(alpha = 0.25f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "Absolute quiet celestial desk.",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = CosmicOnSurfaceMuted
                        )
                        Text(
                            "Dock your first book program above to begin page metrics tracking.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicOnSurfaceMuted.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        } else {
            items(books, key = { it.id }) { book ->
                ActiveBookCard(
                    book = book,
                    onUpdatePages = { newPage -> onUpdatePages(book, newPage) },
                    onDelete = { onDeleteBook(book) },
                    onOpenReader = { onOpenReader(book) }
                )
            }
        }

        // --- COSMIC DISCOVERY LIBRARY AT THE BOTTOM ---
        item {
            Spacer(modifier = Modifier.height(16.dp))
            HorizontalDivider(color = CosmicSurfaceVariant, thickness = 1.dp)
            Spacer(modifier = Modifier.height(16.dp))
            
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Discovery Icon",
                            tint = CosmicTertiary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Cosmic Discovery Library",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CosmicOnBackground
                            )
                            Text(
                                text = "Add and docket your own custom pieces into the Orbit library",
                                style = MaterialTheme.typography.bodySmall,
                                color = CosmicOnSurfaceMuted
                            )
                        }
                    }
                    
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (discoveryLibrary.isNotEmpty()) {
                            IconButton(
                                onClick = onClearDiscoveryLibrary,
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteForever,
                                    contentDescription = "Wipe Discovery Library",
                                    tint = PriorityHigh.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Button(
                            onClick = { showAddToLibraryForm = !showAddToLibraryForm },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showAddToLibraryForm) PriorityHigh.copy(alpha = 0.2f) else CosmicSecondary,
                                contentColor = if (showAddToLibraryForm) PriorityHigh else CosmicBackground
                            ),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(
                                imageVector = if (showAddToLibraryForm) Icons.Default.Close else Icons.Default.Add,
                                contentDescription = "Add library book control",
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (showAddToLibraryForm) "Cancel" else "Add Dynamic Book", fontSize = 11.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        if (showAddToLibraryForm) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Register Dynamic Masterpiece",
                            style = MaterialTheme.typography.titleSmall,
                            color = CosmicSecondary,
                            fontWeight = FontWeight.Bold
                        )
                        
                        OutlinedTextField(
                            value = libBookTitle,
                            onValueChange = { libBookTitle = it },
                            label = { Text("Title", fontSize = 12.sp) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("lib_title_field")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = libBookAuthor,
                                onValueChange = { libBookAuthor = it },
                                label = { Text("Author", fontSize = 12.sp) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicSecondary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("lib_author_field")
                            )

                            OutlinedTextField(
                                value = libBookPages,
                                onValueChange = { libBookPages = it },
                                label = { Text("Total Pages", fontSize = 12.sp) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicSecondary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("lib_pages_field")
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedTextField(
                                value = libBookGenre,
                                onValueChange = { libBookGenre = it },
                                label = { Text("Genre", fontSize = 12.sp) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicSecondary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("lib_genre_field")
                            )

                            OutlinedTextField(
                                value = libBookVibe,
                                onValueChange = { libBookVibe = it },
                                label = { Text("Reading Vibe", fontSize = 12.sp) },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicSecondary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).testTag("lib_vibe_field")
                            )
                        }

                        OutlinedTextField(
                            value = libBookDesc,
                            onValueChange = { libBookDesc = it },
                            label = { Text("Short Description / Sinopsis", fontSize = 12.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth().height(80.dp).testTag("lib_desc_field")
                        )

                        Button(
                            onClick = {
                                if (libBookTitle.trim().isNotEmpty()) {
                                    val pagesNum = libBookPages.toIntOrNull() ?: 100
                                    onAddDiscoveryBook(
                                        libBookTitle,
                                        libBookAuthor,
                                        libBookGenre,
                                        pagesNum,
                                        libBookDesc,
                                        libBookVibe
                                    )
                                    // Reset inputs
                                    libBookTitle = ""
                                    libBookAuthor = ""
                                    libBookGenre = "Fiction"
                                    libBookPages = ""
                                    libBookVibe = ""
                                    libBookDesc = ""
                                    showAddToLibraryForm = false
                                    Toast.makeText(context, "$libBookTitle added to Cosmic Library", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "Please enter a valid book Title", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicTertiary, contentColor = CosmicBackground),
                            modifier = Modifier.fillMaxWidth().height(42.dp).testTag("lib_save_button")
                        ) {
                            Text("Save custom masterpiece to Orbit", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        val freshDiscoveryList = discoveryLibrary.filter { libBook ->
            !books.any { it.title.equals(libBook.title, ignoreCase = true) }
        }

        if (freshDiscoveryList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    Box(
                        modifier = Modifier.padding(20.dp).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.MenuBook,
                                contentDescription = "Empty dynamic library",
                                tint = CosmicOnSurfaceMuted.copy(alpha = 0.4f),
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Your cosmic discovery library behaves dynamically. Tap 'Add Dynamic Book' to fill it with customized celestial reads!",
                                style = MaterialTheme.typography.bodySmall,
                                color = CosmicOnSurfaceMuted,
                                textAlign = TextAlign.Center,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }

        items(freshDiscoveryList) { libBook ->
            val alreadyAdded = false
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicSurface.copy(alpha = 0.5f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("library_book_card_${libBook.title.replace(" ", "_")}")
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Left Column: Custom artistic book cover representation!
                    val coverGradient = when (libBook.genre) {
                        "Science" -> Brush.linearGradient(listOf(CosmicPrimary, CosmicSecondary))
                        "Fantasy" -> Brush.linearGradient(listOf(CosmicPrimary, CosmicTertiary))
                        "Self-Help" -> Brush.linearGradient(listOf(CosmicSecondary, CosmicTertiary))
                        else -> Brush.linearGradient(listOf(PriorityHigh, CosmicSecondary))
                    }
                    
                    val genreIcon = when (libBook.genre) {
                        "Science" -> Icons.Default.Science
                        "Fantasy" -> Icons.Default.AutoAwesome
                        "Self-Help" -> Icons.Default.Lightbulb
                        else -> Icons.Default.Bookmark
                    }

                    Box(
                        modifier = Modifier
                            .size(width = 60.dp, height = 80.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(coverGradient),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = genreIcon,
                                contentDescription = null,
                                tint = CosmicBackground,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = libBook.genre.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = CosmicBackground,
                                fontWeight = FontWeight.Black,
                                fontSize = 8.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    // Center Column: Details
                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = libBook.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = CosmicOnBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${libBook.totalPages} p",
                                style = MaterialTheme.typography.labelSmall,
                                color = CosmicSecondary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = "by ${libBook.author}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicOnSurfaceMuted,
                            fontWeight = FontWeight.Medium
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = libBook.description.ifEmpty { "Discover this new customized celestial reads inside your orbits." },
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicOnSurfaceMuted.copy(alpha = 0.8f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = 11.sp,
                            lineHeight = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "VIBE: ${libBook.readingVibe.ifEmpty { "Personal Vibe" }.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = CosmicTertiary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    // Right Column: Dock Button
                    IconButton(
                        onClick = { onAddBookFromLibrary(libBook.title, libBook.author, libBook.genre, libBook.totalPages) },
                        modifier = Modifier
                            .background(CosmicPrimary, shape = CircleShape)
                            .size(36.dp)
                            .testTag("add_library_book_${libBook.title.replace(" ", "_")}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Dock Book to shelf",
                            tint = CosmicBackground,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveBookCard(
    book: Book,
    onUpdatePages: (Int) -> Unit,
    onDelete: () -> Unit,
    onOpenReader: () -> Unit
) {
    var isEditingProgress by remember { mutableStateOf(false) }
    var pageInputValue by remember { mutableStateOf(book.currentPage.toString()) }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("book_shelf_card_${book.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Title & Author & Genre badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = book.title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = CosmicOnBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "by ${book.author}",
                        style = MaterialTheme.typography.bodySmall,
                        color = CosmicOnSurfaceMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    // Genre badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(CosmicSurfaceVariant)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = book.genre.uppercase(Locale.getDefault()),
                            style = MaterialTheme.typography.labelSmall,
                            color = CosmicSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Default.Delete,
                        contentDescription = "Delete book from shelf",
                        tint = PriorityHigh.copy(alpha = 0.8f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Percentage completion & Page metric text
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${(book.progressPercent * 100).toInt()}% completed",
                    style = MaterialTheme.typography.labelLarge,
                    color = if (book.isCompleted) CosmicTertiary else CosmicPrimary,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "${book.currentPage} / ${book.totalPages} Pages",
                    style = MaterialTheme.typography.bodyMedium,
                    color = CosmicOnSurface
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Linear Progress Indicator
            LinearProgressIndicator(
                progress = { book.progressPercent },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(CircleShape),
                color = if (book.isCompleted) CosmicTertiary else CosmicPrimary,
                trackColor = CosmicSurfaceVariant
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Progress Quick Editor Controls
            if (isEditingProgress) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = pageInputValue,
                        onValueChange = { pageInputValue = it },
                        label = { Text("Log Page Target") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CosmicTertiary,
                            unfocusedBorderColor = CosmicSurfaceVariant
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("page_quick_input_${book.id}")
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val targetPage = pageInputValue.toIntOrNull()
                            if (targetPage != null) {
                                onUpdatePages(targetPage)
                                isEditingProgress = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicTertiary, contentColor = CosmicBackground),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Log")
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (book.isCompleted) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Default.DoneAll, contentDescription = "Finished", tint = CosmicTertiary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Journey Accomplished", style = MaterialTheme.typography.labelSmall, color = CosmicTertiary, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        TextButton(
                            onClick = { isEditingProgress = true },
                            colors = ButtonDefaults.textButtonColors(contentColor = CosmicPrimary)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Progress", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Update Page", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }

                    Button(
                        onClick = onOpenReader,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CosmicTertiary.copy(alpha = 0.2f),
                            contentColor = CosmicTertiary
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag("open_reader_button_${book.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = "Open In-App Reader",
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Open Reader",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ==================== SCHEDULE TAB ====================
@Composable
fun ScheduleTab(
    books: List<Book>,
    schedules: List<ReadingSchedule>,
    showAddScheduleForm: Boolean,
    onToggleAddSchedule: () -> Unit,
    scheduleBookSelected: Book?,
    onBookSelect: (Book?) -> Unit,
    scheduleDateMills: Long,
    onDateSelect: (Long) -> Unit,
    schedulePagesToReadInput: String,
    onPagesChange: (String) -> Unit,
    scheduleNotesInput: String,
    onNotesChange: (String) -> Unit,
    onAddScheduleSubmit: (Boolean, String) -> Unit,
    onDeleteSchedule: (Int) -> Unit,
    onToggleSchedule: (ReadingSchedule) -> Unit,
    onTriggerEmail: (ReadingSchedule) -> Unit,
    onTriggerNotification: (ReadingSchedule) -> Unit,
    preferredEmail: String,
    onSaveEmail: (String) -> Unit,
    enableAutoEmail: Boolean,
    onToggleAutoEmail: (Boolean) -> Unit
) {
    val context = LocalContext.current

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- EMAIL ALERTS SETTINGS CARD ---
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicSurface.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = Icons.Default.Email,
                                contentDescription = "Email Settings Icon",
                                tint = CosmicSecondary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Email Alert Notifications",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = CosmicOnSurface
                                )
                                Text(
                                    text = "Send reminder email when session starts",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CosmicOnSurfaceMuted
                                )
                            }
                        }
                        Switch(
                            checked = enableAutoEmail,
                            onCheckedChange = onToggleAutoEmail,
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CosmicSecondary,
                                checkedTrackColor = CosmicSecondary.copy(alpha = 0.4f)
                            )
                        )
                    }

                    HorizontalDivider(color = CosmicSurfaceVariant, thickness = 1.dp)

                    var emailEditing by remember { mutableStateOf(preferredEmail) }
                    LaunchedEffect(preferredEmail) {
                        emailEditing = preferredEmail
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = emailEditing,
                            onValueChange = { emailEditing = it },
                            label = { Text("Recipient Email Address") },
                            placeholder = { Text("anuragphale2@gmail.com") },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("preferred_email_input")
                        )

                        Button(
                            onClick = {
                                if (emailEditing.trim().isNotEmpty()) {
                                    onSaveEmail(emailEditing.trim())
                                    Toast.makeText(context, "Recipient email address updated!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CosmicSecondary,
                                contentColor = CosmicBackground
                            )
                        ) {
                            Text("Save", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reading Schedules Calendar",
                    style = MaterialTheme.typography.titleMedium,
                    color = CosmicOnBackground,
                    fontWeight = FontWeight.Bold
                )

                Button(
                    onClick = onToggleAddSchedule,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (showAddScheduleForm) PriorityHigh.copy(alpha = 0.2f) else CosmicSecondary,
                        contentColor = if (showAddScheduleForm) PriorityHigh else CosmicBackground
                    )
                ) {
                    Icon(
                        imageVector = if (showAddScheduleForm) Icons.Default.Close else Icons.Default.Add,
                        contentDescription = "Schedule addition toggler"
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (showAddScheduleForm) "Close" else "Plan Reading", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Inline Expandable Add Schedule Form
        if (showAddScheduleForm) {
            item {
                var useManualBookName by remember(books) { mutableStateOf(books.isEmpty()) }
                var manualBookTitle by remember { mutableStateOf("") }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Schedule Planned Reading Session", style = MaterialTheme.typography.titleSmall, color = CosmicSecondary, fontWeight = FontWeight.Bold)

                        // If books is not empty, allow toggling between shelf books and manual titles
                        if (books.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CosmicSurfaceVariant)
                                    .padding(4.dp),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Button(
                                    onClick = { useManualBookName = false },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (!useManualBookName) CosmicSecondary else Color.Transparent,
                                        contentColor = if (!useManualBookName) CosmicBackground else CosmicOnSurface
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("Shelf Book", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                }
                                Button(
                                    onClick = { useManualBookName = true },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (useManualBookName) CosmicSecondary else Color.Transparent,
                                        contentColor = if (useManualBookName) CosmicBackground else CosmicOnSurface
                                    ),
                                    modifier = Modifier.weight(1f),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("Manual Title", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        } else {
                            Text(
                                "No registered books. Schedule using custom title below:",
                                style = MaterialTheme.typography.labelSmall,
                                color = CosmicSecondary
                            )
                        }

                        if (useManualBookName) {
                            OutlinedTextField(
                                value = manualBookTitle,
                                onValueChange = { manualBookTitle = it },
                                label = { Text("Book Title / Reading Topic") },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = CosmicSecondary,
                                    unfocusedBorderColor = CosmicSurfaceVariant
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("schedule_custom_title_input")
                            )
                        } else {
                            // Choose Book Selection Dropdown
                            Text("Select Book from Shelf", style = MaterialTheme.typography.labelSmall, color = CosmicOnSurfaceMuted)
                            var expandedBooksDrop by remember { mutableStateOf(false) }
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CosmicSurfaceVariant)
                                    .clickable { expandedBooksDrop = true }
                                    .padding(12.dp)
                            ) {
                                Text(scheduleBookSelected?.title ?: "Choose Target Book...", color = if (scheduleBookSelected == null) CosmicOnSurfaceMuted else CosmicOnSurface)
                                DropdownMenu(
                                    expanded = expandedBooksDrop,
                                    onDismissRequest = { expandedBooksDrop = false }
                                ) {
                                    books.forEach { b ->
                                        DropdownMenuItem(
                                            text = { Text(b.title) },
                                            onClick = {
                                                onBookSelect(b)
                                                expandedBooksDrop = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Select Date & Time Native Dialog Launcher Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = {
                                    val calendar = Calendar.getInstance()
                                    DatePickerDialog(
                                        context,
                                        { _, year, month, dayOfMonth ->
                                            val innerCalendar = Calendar.getInstance()
                                            innerCalendar.timeInMillis = scheduleDateMills.coerceAtLeast(System.currentTimeMillis())
                                            innerCalendar.set(Calendar.YEAR, year)
                                            innerCalendar.set(Calendar.MONTH, month)
                                            innerCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth)

                                            // Now show Time Picker Dialog
                                            TimePickerDialog(
                                                context,
                                                { _, hourOfDay, minute ->
                                                    innerCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
                                                    innerCalendar.set(Calendar.MINUTE, minute)
                                                    innerCalendar.set(Calendar.SECOND, 0)
                                                    onDateSelect(innerCalendar.timeInMillis)
                                                },
                                                calendar.get(Calendar.HOUR_OF_DAY),
                                                calendar.get(Calendar.MINUTE),
                                                true
                                            ).show()
                                        },
                                        calendar.get(Calendar.YEAR),
                                        calendar.get(Calendar.MONTH),
                                        calendar.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CosmicSurfaceVariant, contentColor = CosmicSecondary),
                                modifier = Modifier.weight(1.5f)
                             ) {
                                Icon(Icons.Default.DateRange, contentDescription = "Calendar Picker Icon")
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Pick Date & Time")
                            }

                            // Show current selected value
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                        .height(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(CosmicSurfaceVariant)
                                    .padding(8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val labelText = if (scheduleDateMills == 0L) {
                                    "Not Chosen"
                                } else {
                                    val formatter = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())
                                    formatter.format(Date(scheduleDateMills))
                                }
                                Text(labelText, style = MaterialTheme.typography.labelSmall, color = CosmicTertiary, fontWeight = FontWeight.Bold)
                            }
                        }

                        // Target pages input
                        OutlinedTextField(
                            value = schedulePagesToReadInput,
                            onValueChange = onPagesChange,
                            label = { Text("How many pages to read?") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("schedule_pages_input")
                        )

                        // Notes memo input
                        OutlinedTextField(
                            value = scheduleNotesInput,
                            onValueChange = onNotesChange,
                            label = { Text("Agenda / Chapters / Notes") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("schedule_notes_input")
                        )

                        Button(
                            onClick = { onAddScheduleSubmit(useManualBookName, manualBookTitle) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicSecondary, contentColor = CosmicBackground),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("schedule_planned_submit")
                        ) {
                            Text("Log Planned Session in Tracker", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Empty Status for Schedules
        if (schedules.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 40.dp)
                        .testTag("schedules_empty_state"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventNote,
                            contentDescription = "Empty Schedule list icon",
                            tint = CosmicSecondary.copy(alpha = 0.25f),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            "No upcoming programs configured.",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = CosmicOnSurfaceMuted
                        )
                        Text(
                            "Schedule reading triggers to coordinate email and alarm alerts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicOnSurfaceMuted.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        } else {
            items(schedules, key = { it.id }) { schedule ->
                ScheduleItemCard(
                    schedule = schedule,
                    onDelete = { onDeleteSchedule(schedule.id) },
                    onToggleComplete = { onToggleSchedule(schedule) },
                    onTriggerEmail = { onTriggerEmail(schedule) },
                    onTriggerNotification = { onTriggerNotification(schedule) }
                )
            }
        }
    }
}

@Composable
fun ScheduleItemCard(
    schedule: ReadingSchedule,
    onDelete: () -> Unit,
    onToggleComplete: () -> Unit,
    onTriggerEmail: () -> Unit,
    onTriggerNotification: () -> Unit
) {
    val dateFormat = SimpleDateFormat("EEEE, d MMMM 'at' HH:mm", Locale.getDefault())
    val dateString = dateFormat.format(Date(schedule.dateTimeMillis))

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (schedule.completed) CosmicSurfaceVariant.copy(alpha = 0.7f) else CosmicSurface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("schedule_item_card_${schedule.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Left Completion checkbox trigger
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Checkbox(
                        checked = schedule.completed,
                        onCheckedChange = { onToggleComplete() },
                        colors = CheckboxDefaults.colors(
                            checkedColor = CosmicTertiary,
                            uncheckedColor = CosmicOnSurfaceMuted
                        ),
                        modifier = Modifier.testTag("schedule_checkbox_${schedule.id}")
                    )

                    Spacer(modifier = Modifier.width(4.dp))

                    Column {
                        Text(
                            text = schedule.bookTitle,
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontWeight = FontWeight.Bold,
                                textDecoration = if (schedule.completed) TextDecoration.LineThrough else TextDecoration.None
                            ),
                            color = if (schedule.completed) CosmicOnSurfaceMuted else CosmicOnBackground
                        )
                        Text(
                            text = "Target Pages: ${schedule.targetPages}",
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicSecondary
                        )
                    }
                }

                IconButton(onClick = onDelete) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete planned event", tint = PriorityHigh.copy(alpha = 0.8f))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Calendar Time Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CosmicSurfaceVariant)
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Icon(Icons.Default.Schedule, contentDescription = "Schedule Date Time Alarm", tint = CosmicTertiary, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(dateString, style = MaterialTheme.typography.bodySmall, color = CosmicOnSurface)
            }

            if (schedule.notes.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Notes: \"${schedule.notes}\"",
                    style = MaterialTheme.typography.bodySmall,
                    color = CosmicOnSurfaceMuted
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Actions row (Send Mail & Push Native notification reminder)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Email button
                OutlinedButton(
                    onClick = onTriggerEmail,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CosmicPrimary),
                    border = ButtonDefaults.outlinedButtonBorder.copy(),
                    modifier = Modifier
                        .weight(1f)
                        .height(38.dp)
                ) {
                    Icon(Icons.Default.Email, contentDescription = "Email scheduled reading reminder", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Send Email", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }

                // Simulate Notification trigger button for the streaming test emulator
                Button(
                    onClick = onTriggerNotification,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CosmicPrimary, contentColor = CosmicBackground),
                    modifier = Modifier
                        .weight(1.2f)
                        .height(38.dp)
                ) {
                    Icon(Icons.Default.NotificationsActive, contentDescription = "Trigger Reminder Alarm Alert", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Trigger Alert", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ==================== GOALS TAB ====================
@Composable
fun GoalsTab(
    goal: WeeklyGoal,
    pagesReadThisWeek: Int,
    readingLogs: List<ReadingLog>,
    showGoalEditor: Boolean,
    onToggleGoalEditor: () -> Unit,
    goalPagesInput: String,
    onGoalPagesChange: (String) -> Unit,
    goalBooksInput: String,
    onGoalBooksChange: (String) -> Unit,
    onSaveGoals: () -> Unit
) {
    val completionPercentage = if (goal.pagesTarget > 0) {
        (pagesReadThisWeek.toFloat() / goal.pagesTarget.toFloat() * 100f).toInt().coerceIn(0, 1000)
    } else {
        0
    }

    LazyColumn(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        item {
            Spacer(modifier = Modifier.height(10.dp))
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Weekly Goals Metrics",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CosmicPrimary
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Large circular progress gauge for the weekly readings
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.size(150.dp)
                    ) {
                        Canvas(modifier = Modifier.size(130.dp)) {
                            // Circular background track
                            drawArc(
                                color = CosmicSurfaceVariant,
                                startAngle = -225f,
                                sweepAngle = 270f,
                                useCenter = false,
                                style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                            )

                            // Dynamic color circular arc of target pages
                            val arcPercentage = (completionPercentage.toFloat() / 100f).coerceIn(0f, 1f)
                            drawArc(
                                color = CosmicTertiary,
                                startAngle = -225f,
                                sweepAngle = arcPercentage * 270f,
                                useCenter = false,
                                style = Stroke(width = 14.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "$completionPercentage%",
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Black,
                                color = CosmicOnBackground
                            )
                            Text(
                                text = "Weekly Goal",
                                style = MaterialTheme.typography.labelSmall,
                                color = CosmicOnSurfaceMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "Scoreboard: $pagesReadThisWeek / ${goal.pagesTarget} Pages read this week",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = CosmicOnSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onToggleGoalEditor,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CosmicSurfaceVariant, contentColor = CosmicSecondary)
                    ) {
                        Icon(Icons.Default.Settings, contentDescription = "Edit metrics config")
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (showGoalEditor) "Close Target Config" else "Edit Goal Targets", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Inline Goal Config Editor Form
        if (showGoalEditor) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CosmicSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Configure Goals", style = MaterialTheme.typography.titleSmall, color = CosmicSecondary, fontWeight = FontWeight.Bold)

                        OutlinedTextField(
                            value = goalPagesInput,
                            onValueChange = onGoalPagesChange,
                            label = { Text("Target Pages Per Week") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("goal_pages_field")
                        )

                        OutlinedTextField(
                            value = goalBooksInput,
                            onValueChange = onGoalBooksChange,
                            label = { Text("Target Books Complete Per Week") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = CosmicSecondary,
                                unfocusedBorderColor = CosmicSurfaceVariant
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("goal_books_field")
                        )

                        Button(
                            onClick = onSaveGoals,
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicTertiary, contentColor = CosmicBackground),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                                .testTag("save_goals_submit")
                        ) {
                            Text("Save Configurations", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

// Past 7 Days Elegant Bar Graph Composable
@Composable
fun WeeklyReadingLogGraph(readingLogs: List<ReadingLog>) {
    // Generate pages maps in the past 7 days (index 0 is 6 days ago, index 6 is today)
    val past7DaysRange = remember(readingLogs) {
        val calendar = Calendar.getInstance()
        val daysData = List(7) { i ->
            val dCal = Calendar.getInstance()
            dCal.add(Calendar.DAY_OF_YEAR, -(6 - i))
            dCal.set(Calendar.HOUR_OF_DAY, 0)
            dCal.clear(Calendar.MINUTE)
            dCal.clear(Calendar.SECOND)
            dCal.clear(Calendar.MILLISECOND)

            val dayStart = dCal.timeInMillis
            val dayEnd = dayStart + (24 * 60 * 60 * 1000L)

            val sum = readingLogs.filter { it.dateEpochMillis in dayStart until dayEnd }.sumOf { it.pagesRead }

            val letter = when (dCal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SUNDAY -> "Su"
                Calendar.MONDAY -> "Mo"
                Calendar.TUESDAY -> "Tu"
                Calendar.WEDNESDAY -> "We"
                Calendar.THURSDAY -> "Th"
                Calendar.FRIDAY -> "Fr"
                Calendar.SATURDAY -> "Sa"
                else -> ""
            }

            Pair(letter, sum)
        }
        daysData
    }

    val maxPagesInADay = remember(past7DaysRange) {
        past7DaysRange.maxOf { it.second }.coerceAtLeast(10)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CosmicSurface),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("historical_bar_graph")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Past 7 Days Pages Read", style = MaterialTheme.typography.titleSmall, color = CosmicSecondary, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            // Graph canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height

                    val paddingX = 20.dp.toPx()
                    val barWidth = 32.dp.toPx()
                    val totalBarsCount = 7

                    val spaceBetween = (width - (paddingX * 2) - (barWidth * totalBarsCount)) / (totalBarsCount - 1)

                    past7DaysRange.forEachIndexed { idx, pair ->
                        val pages = pair.second
                        val barHeight = (pages.toFloat() / maxPagesInADay.toFloat()) * (height - 30.dp.toPx())

                        val barLeft = paddingX + idx * (barWidth + spaceBetween)
                        val barTop = height - 20.dp.toPx() - barHeight

                        // Draw background track for bar
                        drawRoundRect(
                            color = CosmicSurfaceVariant,
                            topLeft = Offset(barLeft, 0f),
                            size = Size(barWidth, height - 20.dp.toPx()),
                            cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                        )

                        // Draw live active filled reading progress bar with brush gradient
                        if (pages > 0) {
                            val activeBrush = Brush.verticalGradient(
                                colors = listOf(CosmicPrimary, CosmicTertiary)
                            )
                            drawRoundRect(
                                brush = activeBrush,
                                topLeft = Offset(barLeft, barTop),
                                size = Size(barWidth, barHeight),
                                cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx())
                            )
                        }

                        // Drawing text label values of columns inline
                        // For simplicity, we can do it via drawContext, or center them
                    }
                }

                // Row overlay of labels
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .padding(horizontal = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    past7DaysRange.forEach { pair ->
                        Box(
                            modifier = Modifier.width(36.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = if (pair.second > 0) "${pair.second}" else "•",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (pair.second > 0) CosmicTertiary else CosmicOnSurfaceMuted,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = pair.first,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = CosmicOnSurfaceMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==================== ALERTS TAB ====================
@Composable
fun AlertsTab(
    notifications: List<com.example.data.InAppNotification>,
    onMarkAsRead: (com.example.data.InAppNotification) -> Unit,
    onDeleteNotification: (Int) -> Unit,
    onClearAll: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().testTag("alerts_tab_lazy_list"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Reading Alerts Center",
                    style = MaterialTheme.typography.titleMedium,
                    color = CosmicOnBackground,
                    fontWeight = FontWeight.Bold
                )

                if (notifications.isNotEmpty()) {
                    TextButton(
                        onClick = onClearAll,
                        colors = ButtonDefaults.textButtonColors(contentColor = PriorityHigh)
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear all notifications",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear All", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (notifications.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .testTag("notifications_empty_state"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(modifier = Modifier.height(20.dp))
                        Icon(
                            imageVector = Icons.Default.NotificationsOff,
                            contentDescription = "No Alerts Registered",
                            tint = CosmicPrimary.copy(alpha = 0.25f),
                            modifier = Modifier.size(72.dp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            "Your skies are perfectly clear.",
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            color = CosmicOnSurfaceMuted
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "When scheduled reading targets are reached, real-time cosmic alerts will dock here.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CosmicOnSurfaceMuted.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        } else {
            items(notifications, key = { it.id }) { notification ->
                NotificationItemCard(
                    notification = notification,
                    onMarkRead = { onMarkAsRead(notification) },
                    onDelete = { onDeleteNotification(notification.id) }
                )
            }
        }
    }
}

@Composable
fun NotificationItemCard(
    notification: com.example.data.InAppNotification,
    onMarkRead: () -> Unit,
    onDelete: () -> Unit
) {
    val formatter = remember(notification.timestamp) {
        SimpleDateFormat("MMM d, HH:mm:ss", Locale.getDefault())
    }
    val timeLabel = formatter.format(Date(notification.timestamp))

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (notification.isRead) CosmicSurfaceVariant.copy(alpha = 0.6f) else CosmicSurface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onMarkRead() }
            .testTag("notification_card_${notification.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Unread visual priority cosmic orb indicator
            if (!notification.isRead) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(CosmicTertiary)
                        .testTag("unread_indicator_${notification.id}")
                )
                Spacer(modifier = Modifier.width(10.dp))
            } else {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(Color.Transparent)
                )
                Spacer(modifier = Modifier.width(10.dp))
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "📖 READING MOMENTUM REACHED",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (notification.isRead) CosmicOnSurfaceMuted else CosmicPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = timeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = CosmicOnSurfaceMuted,
                        fontSize = 11.sp
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = notification.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontWeight = if (notification.isRead) FontWeight.Normal else FontWeight.Bold
                    ),
                    color = if (notification.isRead) CosmicOnSurfaceMuted else CosmicOnBackground
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = notification.message,
                    style = MaterialTheme.typography.bodySmall,
                    color = CosmicOnSurfaceMuted
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.testTag("notification_delete_${notification.id}")
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Remove notification",
                    tint = PriorityHigh.copy(alpha = 0.6f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}
