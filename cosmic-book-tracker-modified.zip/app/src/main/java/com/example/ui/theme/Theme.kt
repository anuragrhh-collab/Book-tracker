package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme =
  lightColorScheme(
    primary = CosmicPrimary,
    secondary = CosmicSecondary,
    tertiary = CosmicTertiary,
    background = CosmicBackground,
    surface = CosmicSurface,
    surfaceVariant = CosmicSurfaceVariant,
    onBackground = CosmicOnBackground,
    onSurface = CosmicOnSurface,
    onSurfaceVariant = CosmicOnSurfaceMuted
  )

private val DarkColorScheme = LightColorScheme // Beautiful unified light/bright appearance mapping to the user design request

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = false, // Set default to false to apply our soft, beautiful, and bright light theme
  dynamicColor: Boolean = false, // Preserve our custom palette
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
