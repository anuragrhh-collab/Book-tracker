package com.example.data

import kotlinx.coroutines.flow.Flow

class BookRepository(private val bookDao: BookDao) {
    val allBooks: Flow<List<Book>> = bookDao.getAllBooks()
    val allSchedules: Flow<List<ReadingSchedule>> = bookDao.getAllSchedules()
    val allReadingLogs: Flow<List<ReadingLog>> = bookDao.getAllReadingLogs()
    val weeklyGoal: Flow<WeeklyGoal?> = bookDao.getWeeklyGoal()

    suspend fun insertBook(book: Book): Long {
        return bookDao.insertBook(book)
    }

    suspend fun updateBook(book: Book) {
        bookDao.updateBook(book)
    }

    suspend fun deleteBook(book: Book) {
        bookDao.deleteBook(book)
        bookDao.deleteReadingLogsForBook(book.id)
    }

    suspend fun insertSchedule(schedule: ReadingSchedule) {
        bookDao.insertSchedule(schedule)
    }

    suspend fun deleteScheduleById(id: Int) {
        bookDao.deleteScheduleById(id)
    }

    suspend fun updateScheduleCompleted(id: Int, completed: Boolean) {
        bookDao.updateScheduleCompleted(id, completed)
    }

    suspend fun insertReadingLog(log: ReadingLog) {
        bookDao.insertReadingLog(log)
    }

    fun getReadingLogsSince(startLimit: Long): Flow<List<ReadingLog>> {
        return bookDao.getReadingLogsSince(startLimit)
    }

    suspend fun insertWeeklyGoal(goal: WeeklyGoal) {
        bookDao.insertWeeklyGoal(goal)
    }

    // ---- IN APP NOTIFICATIONS ----
    val allNotifications: Flow<List<InAppNotification>> = bookDao.getAllNotifications()

    suspend fun insertNotification(notification: InAppNotification): Long {
        return bookDao.insertNotification(notification)
    }

    suspend fun updateNotificationReadStatus(id: Int, isRead: Boolean) {
        bookDao.updateNotificationReadStatus(id, isRead)
    }

    suspend fun deleteNotificationById(id: Int) {
        bookDao.deleteNotificationById(id)
    }

    suspend fun clearAllNotifications() {
        bookDao.clearAllNotifications()
    }
}
