package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "books")
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val author: String,
    val genre: String,
    val totalPages: Int,
    var currentPage: Int,
    val uploadedText: String? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingPages: Int
        get() = (totalPages - currentPage).coerceAtLeast(0)

    val progressPercent: Float
        get() = if (totalPages > 0) {
            (currentPage.toFloat() / totalPages.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    val isCompleted: Boolean
        get() = currentPage >= totalPages && totalPages > 0
}
