package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {
    // ---- BOOKS ----
    @Query("SELECT * FROM books ORDER BY createdAt DESC")
    fun getAllBooks(): Flow<List<Book>>

    @Query("SELECT * FROM books WHERE id = :id LIMIT 1")
    suspend fun getBookById(id: Int): Book?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBook(book: Book): Long

    @Update
    suspend fun updateBook(book: Book)

    @Delete
    suspend fun deleteBook(book: Book)

    // ---- READING SCHEDULES ----
    @Query("SELECT * FROM reading_schedules ORDER BY dateTimeMillis ASC")
    fun getAllSchedules(): Flow<List<ReadingSchedule>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: ReadingSchedule)

    @Query("DELETE FROM reading_schedules WHERE id = :id")
    suspend fun deleteScheduleById(id: Int)

    @Query("UPDATE reading_schedules SET completed = :completed WHERE id = :id")
    suspend fun updateScheduleCompleted(id: Int, completed: Boolean)

    // ---- READING LOGS ----
    @Query("SELECT * FROM reading_logs ORDER BY dateEpochMillis DESC")
    fun getAllReadingLogs(): Flow<List<ReadingLog>>

    @Query("SELECT * FROM reading_logs WHERE dateEpochMillis >= :startLimit ORDER BY dateEpochMillis ASC")
    fun getReadingLogsSince(startLimit: Long): Flow<List<ReadingLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReadingLog(log: ReadingLog)

    @Query("DELETE FROM reading_logs WHERE bookId = :bookId")
    suspend fun deleteReadingLogsForBook(bookId: Int)

    // ---- WEEKLY GOALS ----
    @Query("SELECT * FROM weekly_goals WHERE id = 1 LIMIT 1")
    fun getWeeklyGoal(): Flow<WeeklyGoal?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWeeklyGoal(goal: WeeklyGoal)

    // ---- IN APP NOTIFICATIONS ----
    @Query("SELECT * FROM in_app_notifications ORDER BY timestamp DESC")
    fun getAllNotifications(): Flow<List<InAppNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: InAppNotification): Long

    @Query("UPDATE in_app_notifications SET isRead = :isRead WHERE id = :id")
    suspend fun updateNotificationReadStatus(id: Int, isRead: Boolean)

    @Query("DELETE FROM in_app_notifications WHERE id = :id")
    suspend fun deleteNotificationById(id: Int)

    @Query("DELETE FROM in_app_notifications")
    suspend fun clearAllNotifications()
}
