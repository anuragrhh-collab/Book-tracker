package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reading_schedules")
data class ReadingSchedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val bookId: Int,
    val bookTitle: String,
    val dateTimeMillis: Long,
    val targetPages: Int = 10,
    val notes: String = "",
    val completed: Boolean = false,
    val remindMe: Boolean = true
)
