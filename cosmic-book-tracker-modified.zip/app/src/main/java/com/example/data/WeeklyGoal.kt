package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weekly_goals")
data class WeeklyGoal(
    @PrimaryKey val id: Int = 1, // Single row entry
    val pagesTarget: Int = 100,  // custom pages target per week (default 100)
    val booksTarget: Int = 1     // custom books target per week (default 1)
)
