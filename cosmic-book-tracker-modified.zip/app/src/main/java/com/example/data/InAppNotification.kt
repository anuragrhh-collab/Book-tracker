package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "in_app_notifications")
data class InAppNotification(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val bookTitle: String = "",
    val scheduleId: Int = 0
)
